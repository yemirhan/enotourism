# Enotourism

## How to run
- Docker must be installed on your machine

```bash
npm install
npx prisma db push
npm run dev
```